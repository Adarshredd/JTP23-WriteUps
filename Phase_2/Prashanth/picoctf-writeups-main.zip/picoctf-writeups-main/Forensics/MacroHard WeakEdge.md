## Description
I've hidden a flag in this file. Can you find it? Forensics is fun.pptm
## Approach
the ppt file given is empty <br>
I extracted the file and went through the folders and found a hidden file [file name is "hidden"]

![image](https://github.com/Adarshredd/picoctf-writeups/assets/145366498/c8397c99-9fa8-48dd-831c-7af5ba061b75)

![image](https://github.com/Adarshredd/picoctf-writeups/assets/145366498/fb5e10af-8bc2-4bf0-8168-097d4d95dcda)

decode the text using `base64`

![image](https://github.com/Adarshredd/picoctf-writeups/assets/145366498/d18df51f-4bbf-4042-a1ee-db8123362455)

flag: `picoCTF{D1d_u_kn0w_ppts_r_z1p5}`
