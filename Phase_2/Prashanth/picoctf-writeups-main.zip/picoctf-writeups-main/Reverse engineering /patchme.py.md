open the patchme.py file <br>
go to terminal and change directory to Desktop(where the flag.txt is stored)

now run the file<br>
it asks
```py
Please enter correct password for flag:
```

so I'll print the password which is already mentioned in the file but is not in order
```py
print("ak98" + \
                   "-=90" + \
                   "adfjhgj321" + \
                   "sleuth9000")
```

now if u run the file, it will print the password and ask for it again <br>
just copy and paste the pass to get the flag

![image](https://github.com/Adarshredd/picoctf-writeups/assets/145366498/4b5ed41a-c741-4f76-9cb4-816cd195745a)

