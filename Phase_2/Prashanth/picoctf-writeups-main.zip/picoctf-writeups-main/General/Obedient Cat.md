## Description
This file has a flag in plain sight (aka "in-the-clear"). Download flag.
## Approach
open the file in terminal using<br>
```py
wget https://mercury.picoctf.net/static/a5683698ac318b47bd060cb786859f23/flag
```
![image](https://github.com/Adarshredd/picoctf-writeups/assets/145366498/563d641d-9a76-43d8-8fb0-c0de7b6b73fd)
`cat flag` to see its contents

flag:`picoCTF{s4n1ty_v3r1f13d_4a2b35fd}`
