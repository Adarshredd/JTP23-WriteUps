To get the file accessible in your shell enter in the Terminal prompt:<br>
`wget https://mercury.picoctf.net/static/fc1d77192c544314efece5dd309092e3/warm`

now run the program by entering `./warm`<br>
but u have to make the file executable by `chmod +x warm`<br>
then it asks to pass `-h` to find out what it does 
![image](https://github.com/Adarshredd/picoctf-writeups/assets/145366498/0f309711-51bc-482c-9f4c-fb6e12bb8079)
`picoCTF{b1scu1ts_4nd_gr4vy_6635aa47}`
