# picoGYM⛹ 
|          `DOMAIN` | `COUNT` | `pending`
|-------------------|---------|------------
|Binary Exploitation|    3    |   -
|Cryptography       |    4    |   -
|WEB Exploitation   |    7    |   -
|Forensics          |    3    |   -
|REV engineering    |    6    |   -
|General            |    2    |   -
